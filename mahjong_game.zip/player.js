export class Player {
  constructor(name) {
    this.name = name;
    this.hand = [];
  }
  draw(tile) {
    this.hand.push(tile);
  }
  discard(index) {
    return this.hand.splice(index, 1)[0];
  }
}
