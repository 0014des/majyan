export function canPon(hand, tile) {
  return hand.filter(t => t === tile).length >= 2;
}
export function canChii(hand, tile) {
  return false; // 簡略化のため無効
}
