import { createWall } from './tiles.js';
import { Player } from './player.js';
import { evaluateYaku } from './yaku.js';

const wall = createWall();
const player = new Player("You");

for (let i = 0; i < 13; i++) player.draw(wall.pop());

function updateHandDisplay() {
  const handDiv = document.getElementById("player-hand");
  handDiv.innerHTML = '';
  player.hand.forEach((tile, index) => {
    const tileDiv = document.createElement("div");
    tileDiv.className = "tile";
    tileDiv.textContent = tile;
    tileDiv.onclick = () => {
      const discarded = player.discard(index);
      document.getElementById("message").textContent = `捨て牌: ${discarded}`;
      updateHandDisplay();
    };
    handDiv.appendChild(tileDiv);
  });
}

document.getElementById("draw-button").onclick = () => {
  const tile = wall.pop();
  player.draw(tile);
  document.getElementById("message").textContent = `ツモ: ${tile}`;
  updateHandDisplay();
};

updateHandDisplay();
