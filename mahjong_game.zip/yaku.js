export function evaluateYaku(hand) {
  if (isTanyao(hand)) return "断么九";
  return "役なし";
}
function isTanyao(hand) {
  return hand.every(tile => {
    const num = parseInt(tile[0]);
    return num > 1 && num < 9;
  });
}
